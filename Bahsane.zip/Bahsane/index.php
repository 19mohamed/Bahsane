<?php 
  
include 'config.php';

if (isset($_POST['login'])) {
   
$Name = $_POST['name'];
$Pass = $_POST['pass'];


$sql = mysqli_query($conn,"SELECT COUNT(*) FROM Users WHERE Name='$Name' AND Pass='$Pass'");


$check = mysqli_num_rows($sql);


if ($Name == 'mohmed' && $Pass ==123  ) {



header("location: admin/index.php");

}


}











 ?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="img/logo/attnlg.jpg" rel="icon">
  <title>System - Login</title>
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/ruang-admin.min.css" rel="stylesheet">

</head>

<body class="bg-gradient-login" style="background-image: url('img/lo.jpg');">
  <!-- Login Content -->
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-xl-5 col-lg-8 col-md-7">
        <div class="card shadow-sm my-5"> 
          <div class="card-body p-0" style="background:Gray; color: white"> 
            <div class="row">
              <div class="col-lg-12">
                <div class="login-form"> 
                <h5 align="center">Bahsane Kids Zone</h5>
                  <div class="text-center">
                    <img src="img/logo/attnlg.jpg" style="width:80px;height:80px">
                    <br>
                    <h1 class="h4 text-light-900 mb-2">Admin Login Panel</h1>
                  </div>
                  <form class="user" method="POST" action="">
                    <div class="form-group">
                      <input type="text" class="form-control" required name="name" id="exampleInputEmail" placeholder="Enter Email Address">
                    </div>
                    <div class="form-group">
                      <input type="password" name = "pass" required class="form-control" id="exampleInputPassword" placeholder="Enter Password">
                    </div>
                    <div class="form-group">
                      <div class="custom-control custom-checkbox small" style="line-height: 1.5rem;">
                        <input type="checkbox" class="custom-control-input" id="customCheck">
                        <!-- <label class="custom-control-label" for="customCheck">Remember
                          Me</label> -->
                      </div>
                    </div>
                    <div class="form-group">
                        <input type="submit"  class="btn btn-success btn-block" value="Login" name="login" />
                    </div>
                     </form>


                    <!-- <hr>
                    <a href="index.html" class="btn btn-google btn-block">
                      <i class="fab fa-google fa-fw"></i> Login with Google
                    </a>
                    <a href="index.html" class="btn btn-facebook btn-block">
                      <i class="fab fa-facebook-f fa-fw"></i> Login with Facebook
                    </a> -->

                
                  <div class="text-center">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Login Content -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="js/ruang-admin.min.js"></script>
</body>

</html>