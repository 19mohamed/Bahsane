
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="img/logo/attnlg.jpg" rel="icon">
<?php include 'includes/title.php';?>
  <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/ruang-admin.min.css" rel="stylesheet">
</head>

<body id="page-top">
  <div id="wrapper">
    <!-- Sidebar -->
      <?php include "Includes/sidebar.php";?>
    <!-- Sidebar -->
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <!-- TopBar -->
       <?php include "Includes/topbar.php";?>
        <!-- Topbar -->

        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Equibment</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">View Equibment-Information</li>
            </ol>
          </div>

           <div class="row">
            <div class="col-lg-12">
              <!-- Form Basic -->
             

              <!-- Input Group -->
                 <div class="row">
              <div class="col-lg-12">
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">View Emp-Information</h6>
                </div>
                <div class="table-responsive p-3">
                  <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                    <thead class="thead-light">
                      <tr>
                        <th>Serial NO</th>
                        <th>Name</th>
                        <th>type</th>
                        <th>amount</th>
                        <th>status</th>
                        <th>Edit</th>
                        <th>Delete</th>
                      </tr>
                    </thead>
          
     <?php 
     
     include 'config.php';

$query= mysqli_query($conn, "SELECT * FROM equibment");
while ($row = mysqli_fetch_array($query)) {
      ?>             
                  
                    <tbody>

                            <td><?php echo $row['0']; ?></td>
                            <td><?php echo $row['1']; ?></td>
                            <td><?php echo $row['2']; ?></td>
                            <td><?php echo $row['3']; ?></td>
                            <td><?php echo $row['4']; ?></td>
                           
                          
                            <td><a href="editemployee.php?ID=<?php echo$row['0']; ?>"><i class='fas fa-fw fa-edit'></i></a></td>
                            <td><a href="deleteequibment.php?ID=<?php echo$row['0']; ?>"><i class='fas fa-fw fa-trash'></i></a></td>


                           

                    </tbody>
                    <?php } ?>
                  </table>
                </div>
              </div>
            </div>
            </div>
          </div>
          <!--Row-->





        </div>
        <!---Container Fluid-->
      </div>
      <!-- Footer -->
       <?php include "Includes/footer.php";?>
      <!-- Footer -->
    </div>
  </div>


<!--script Secton start-->

<?php 
include'includes/script.php'; 
 ?>

<!--script Secton ends-->



  <!-- Page level custom scripts -->
  <script>
    $(document).ready(function () {
      $('#dataTable').DataTable(); // ID From dataTable 
      $('#dataTableHover').DataTable(); // ID From dataTable with Hover
    });
  </script>
</body>

</html>