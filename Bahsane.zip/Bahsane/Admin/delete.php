<?php 
include 'config.php';

if (isset($_GET['ID'])) {


$ID = $_GET['ID'];

$sql= mysqli_query($conn, "DELETE FROM `employee` WHERE `employee`.`ID` = $ID");

if ($sql) {
    header('location: addemployee.php');
}

else{
	echo "error";
}

}

?>