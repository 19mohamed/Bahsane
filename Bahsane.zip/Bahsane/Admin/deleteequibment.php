<?php 
include 'config.php';

if (isset($_GET['ID'])) {


$ID = $_GET['ID'];

$sql= mysqli_query($conn, "DELETE FROM `equibment` WHERE `employee`.`ID` = $ID");

if ($sql) {
    header('location: viewequibment.php');
}

else{
	echo "error";
}

}

?>