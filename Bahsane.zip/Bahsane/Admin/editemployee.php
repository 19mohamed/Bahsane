<?php 

include 'config.php';


if (isset($_GET['ID'])) {


$ID = $_GET['ID'];

$sql = mysqli_query($conn, "SELECT * FROM employee
WHERE ID='$ID'");

$row = mysqli_fetch_array($sql);

if (isset($_POST['save'])) {

$EmpName = $_POST['EmpName'];
$phone = $_POST['phone'];
$Occuption = $_POST['Occuption'];
$time = $_POST['time'];
$salary = $_POST['salary'];



$sql= mysqli_query($conn, "UPDATE `employee` SET `Name` = '$EmpName', `phone` = '$phone', `occupation` = '$Occuption', `time` = '$time', `salary` = '$salary' WHERE `employee`.`ID` = $ID");

 if ($sql) {
        header ('Location: addemployee.php');
    }
        else {
            mysqli_error($conn);
        }

}

}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="img/logo/attnlg.jpg" rel="icon">
<?php include 'includes/title.php';?>
  <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/ruang-admin.min.css" rel="stylesheet">
</head>

<body id="page-top">
  <div id="wrapper">
    <!-- Sidebar -->
      <?php include "Includes/sidebar.php";?>
    <!-- Sidebar -->
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <!-- TopBar -->
       <?php include "Includes/topbar.php";?>
        <!-- Topbar -->

        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Employee</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Employee</li>
            </ol>
          </div>

           <div class="row">
            <div class="col-lg-12">
              <!-- Form Basic -->
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Add New Employee</h6>
                    
                </div>
                <div class="card-body">
                  <form method="POST">
                    <div class="form-group row mb-3">
                        <div class="col-xl-6">
                        <label class="form-control-label">Emp-Name<span class="text-danger ml-2">*</span></label>
                      <input type="text" class="form-control" name="EmpName" value="<?php echo$row['1'] ?>" id="exampleInputFirstName" placeholder="Emp-Name">
                                      
                     </div>   
                      
                       <div class="col-xl-6">
                            <label class="form-control-label">Emp-phone<span class="text-danger ml-2">*</span></label>
                      <input type="text" class="form-control" name="phone" value="<?php echo$row['2'] ?>" id="exampleInputFirstName" placeholder="Emp-phone">
                        </div>

                         <div class="col-xl-6 mt-2">
                            <label class="form-control-label">Emp-Occuption<span class="text-danger ml-2">*</span></label>
                      <input type="text" class="form-control" name="Occuption" value="<?php echo$row['3'] ?>" id="exampleInputFirstName" placeholder="Emp-Occuption">
                        </div>

                        <div class="col-xl-6">
                            <label class="form-control-label">Emp-Salary<span class="text-danger ml-2">*</span></label>
                      <input type="text" class="form-control" name="salary" value="<?php echo$row['5'] ?>" id="exampleInputFirstName" placeholder="Emp-Salary">
                        </div>

                        <div class="col-xl-6 mt-2">
                              <label class="form-control-label">Select Class<span class="text-danger ml-2">*</span></label>
                        <div class="col-md-12">
                                       <select name="time" class="form-control">
                                       <option>Select time</option>
                                       <option>Full-Time</option>
                                       <option>Morning</option>
                                       <option>Afternoon</option>

                                     </select>
                        </div>


                        </div>
                    </div>
                    
                    
                    
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <button type="submit" name="save"class="btn btn-warning mt-2">Update</button>
                    
                  </form>
                </div>
              </div>

          
            </div>
          </div>
          <!--Row-->





        </div>
        <!---Container Fluid-->
      </div>
      <!-- Footer -->
       <?php include "Includes/footer.php";?>
      <!-- Footer -->
    </div>
  </div>


<!--script Secton start-->

<?php 
include'includes/script.php'; 
 ?>

<!--script Secton ends-->



  <!-- Page level custom scripts -->
  <script>
    $(document).ready(function () {
      $('#dataTable').DataTable(); // ID From dataTable 
      $('#dataTableHover').DataTable(); // ID From dataTable with Hover
    });
  </script>
</body>

</html>